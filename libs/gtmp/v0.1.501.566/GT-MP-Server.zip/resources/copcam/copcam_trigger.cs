using GrandTheftMultiplayer.Server.API;

public class CopCam : Script
{
	
}